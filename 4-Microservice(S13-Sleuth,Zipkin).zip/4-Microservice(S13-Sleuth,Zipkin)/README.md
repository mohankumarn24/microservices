# microservices
Course notes (https://www.udemy.com/course/microservices-with-java-spring-boot-spring-cloud-eureka-api-gateway/)
